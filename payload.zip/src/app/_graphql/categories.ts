export const CATEGORIES = `categories {
  title
  id
  breadcrumbs {
    id
    label
  }
}`
